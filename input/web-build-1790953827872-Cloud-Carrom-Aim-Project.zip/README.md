# Cloud — Carrom Aim Assistant

A standalone Android project named Cloud.

Included:
- Carrom board UI
- Striker and coin rendering
- Touch-to-aim trajectory line
- Basic trajectory/bank preview
- Portrait Android app

Build:
1. Open this project in Android Studio.
2. Sync Gradle.
3. Build > Build APK(s).

This project does not contain or copy proprietary code from third-party games/apps.
