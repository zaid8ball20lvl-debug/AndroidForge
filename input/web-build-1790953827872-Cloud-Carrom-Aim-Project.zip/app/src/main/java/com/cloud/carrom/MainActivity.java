package com.cloud.carrom;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new CloudBoard(this));
    }

    static class CloudBoard extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float sx, sy, aimX, aimY;
        boolean aiming = false;
        ArrayList<PointF> coins = new ArrayList<>();
        float pocketR;

        CloudBoard(Context c) {
            super(c);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            coins.add(new PointF(.50f,.50f));
            coins.add(new PointF(.43f,.50f));
            coins.add(new PointF(.57f,.50f));
            coins.add(new PointF(.50f,.43f));
            coins.add(new PointF(.50f,.57f));
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            float size=Math.min(w,h-150);
            float l=(w-size)/2f, t=80, r=l+size, bot=t+size;

            c.drawColor(Color.rgb(16,24,32));
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(214,176,112));
            c.drawRoundRect(l,t,r,bot,28,28,p);

            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(12); p.setColor(Color.rgb(94,55,30));
            c.drawRoundRect(l+8,t+8,r-8,bot-8,20,20,p);
            p.setStrokeWidth(3); p.setColor(Color.rgb(80,45,25));
            c.drawRect(l+45,t+45,r-45,bot-45,p);

            pocketR=size*.045f;
            p.setStyle(Paint.Style.FILL); p.setColor(Color.BLACK);
            for(float[] q:new float[][]{{l+48,t+48},{r-48,t+48},{l+48,bot-48},{r-48,bot-48}})
                c.drawCircle(q[0],q[1],pocketR,p);

            float cx=l+size*.5f, cy=t+size*.5f;
            p.setColor(Color.rgb(205,30,45)); c.drawCircle(cx,cy,size*.035f,p);

            for(PointF q:coins) {
                float x=l+q.x*size, y=t+q.y*size;
                p.setColor(Color.rgb(235,235,235)); c.drawCircle(x,y,size*.028f,p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.DKGRAY);
                c.drawCircle(x,y,size*.028f,p); p.setStyle(Paint.Style.FILL);
            }

            float strikerX=l+size*.5f, strikerY=bot-size*.13f;
            p.setColor(Color.WHITE); c.drawCircle(strikerX,strikerY,size*.034f,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.GRAY);
            c.drawCircle(strikerX,strikerY,size*.034f,p); p.setStyle(Paint.Style.FILL);

            if(aiming) {
                p.setColor(Color.rgb(40,210,255)); p.setStrokeWidth(5);
                c.drawLine(strikerX,strikerY,aimX,aimY,p);
                p.setStrokeWidth(2);
                // simple bank preview
                float dx=aimX-strikerX, dy=aimY-strikerY;
                float len=(float)Math.sqrt(dx*dx+dy*dy);
                if(len>1) {
                    float ux=dx/len, uy=dy/len;
                    c.drawLine(aimX,aimY,aimX+ux*size*.12f,aimY+uy*size*.12f,p);
                }
            }

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE);
            p.setTextSize(22);
            c.drawText("CLOUD", 24, 38, p);
            p.setTextSize(14); p.setColor(Color.LTGRAY);
            c.drawText("Carrom Aim Assistant", 24, 61, p);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            float w=getWidth(), h=getHeight(), size=Math.min(w,h-150);
            float l=(w-size)/2f, t=80, bot=t+size;
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
                aiming=true; aimX=e.getX(); aimY=e.getY(); invalidate(); return true;
            }
            if(e.getAction()==MotionEvent.ACTION_UP) {
                aiming=false; invalidate(); return true;
            }
            return true;
        }
    }
}
