# AIM AI Replacement — recovery notes

Source reference: AimAI-Engine-2.2.8 APK supplied by the user.

Included:
- Clean Android application shell.
- Recoverable raster resources copied from the APK and normalized to Android resource names.
- Package/application structure chosen for a fresh replacement project.

Intentionally NOT included:
- Original key/license/activation verification.
- `libaimloader.so` native loader.
- Original signing certificates/keys.
- Original signed runtime/bootstrap artifacts.

The APK's compiled DEX and native loader cannot be turned back into the original source with fidelity. Further features must be reconstructed from observable app behavior or source material owned by the developer.
