package com.aimai.replacement;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Clean replacement shell reconstructed from recoverable APK metadata/resources.
 * No original key/license/verification code or native loader is included.
 */
public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.WHITE);
        TextView title = new TextView(this);
        title.setText("AIM AI Replacement");
        title.setTextColor(Color.BLACK);
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView info = new TextView(this);
        info.setText("Clean rebuild shell\nOriginal key/verification layer is not included.");
        info.setTextColor(Color.DKGRAY);
        info.setTextSize(14);
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 24; root.addView(info, p);
        setContentView(root);
    }
}
